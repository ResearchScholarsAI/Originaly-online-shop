ALTER TABLE `customers` ADD `supabaseUserId` varchar(128);--> statement-breakpoint
ALTER TABLE `customers` ADD `authProvider` varchar(40) DEFAULT 'supabase';--> statement-breakpoint
ALTER TABLE `customers` ADD `authStatus` varchar(20) DEFAULT 'unverified' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `lastAuthAt` timestamp;--> statement-breakpoint
ALTER TABLE `customers` ADD CONSTRAINT `customers_supabaseUserId_unique` UNIQUE(`supabaseUserId`);