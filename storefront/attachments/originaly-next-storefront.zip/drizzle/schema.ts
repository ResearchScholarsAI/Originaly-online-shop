import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from 'drizzle-orm/mysql-core';

export const users = mysqlTable('users', {
  id: int('id').autoincrement().primaryKey(),
  openId: varchar('openId', { length: 64 }).notNull().unique(),
  name: text('name'),
  email: varchar('email', { length: 320 }),
  loginMethod: varchar('loginMethod', { length: 64 }),
  role: mysqlEnum('role', ['user', 'admin']).default('user').notNull(),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp('lastSignedIn').defaultNow().notNull(),
});

export const customers = mysqlTable('customers', {
  id: int('id').autoincrement().primaryKey(),
  phone: varchar('phone', { length: 20 }).notNull().unique(),
  supabaseUserId: varchar('supabaseUserId', { length: 128 }).unique(),
  authProvider: varchar('authProvider', { length: 40 }).default('supabase'),
  authStatus: varchar('authStatus', { length: 20 }).default('unverified').notNull(),
  lastAuthAt: timestamp('lastAuthAt'),
  fullName: varchar('fullName', { length: 160 }),
  email: varchar('email', { length: 320 }),
  city: varchar('city', { length: 100 }),
  address: text('address'),
  postalCode: varchar('postalCode', { length: 20 }),
  phoneVerifiedAt: timestamp('phoneVerifiedAt'),
  marketingConsentAt: timestamp('marketingConsentAt'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export const otpChallenges = mysqlTable('otpChallenges', {
  id: int('id').autoincrement().primaryKey(),
  phone: varchar('phone', { length: 20 }).notNull(),
  codeHash: varchar('codeHash', { length: 128 }).notNull(),
  attempts: int('attempts').default(0).notNull(),
  expiresAt: timestamp('expiresAt').notNull(),
  consumedAt: timestamp('consumedAt'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
});

export const inventoryProducts = mysqlTable('inventoryProducts', {
  id: int('id').autoincrement().primaryKey(),
  sku: varchar('sku', { length: 80 }).notNull().unique(),
  slug: varchar('slug', { length: 180 }).notNull().unique(),
  name: varchar('name', { length: 180 }).notNull(),
  brand: varchar('brand', { length: 120 }).notNull(),
  category: varchar('category', { length: 80 }).notNull(),
  price: int('price').notNull(),
  compareAt: int('compareAt'),
  stock: int('stock').default(0).notNull(),
  lowStockThreshold: int('lowStockThreshold').default(3).notNull(),
  sizes: text('sizes'),
  imageUrl: text('imageUrl'),
  active: int('active').default(1).notNull(),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export const orders = mysqlTable('orders', {
  id: int('id').autoincrement().primaryKey(),
  trackingCode: varchar('trackingCode', { length: 40 }).notNull().unique(),
  customerId: int('customerId'),
  customerPhone: varchar('customerPhone', { length: 20 }).notNull(),
  customerName: varchar('customerName', { length: 160 }).notNull(),
  city: varchar('city', { length: 100 }).notNull(),
  address: text('address').notNull(),
  postalCode: varchar('postalCode', { length: 20 }).notNull(),
  subtotal: int('subtotal').notNull(),
  shipping: int('shipping').notNull(),
  total: int('total').notNull(),
  status: mysqlEnum('status', ['pending', 'confirmed', 'packed', 'shipped', 'delivered', 'cancelled']).default('pending').notNull(),
  paymentStatus: mysqlEnum('paymentStatus', ['unpaid', 'paid', 'refunded']).default('unpaid').notNull(),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export const orderItems = mysqlTable('orderItems', {
  id: int('id').autoincrement().primaryKey(),
  orderId: int('orderId').notNull(),
  sku: varchar('sku', { length: 80 }).notNull(),
  productName: varchar('productName', { length: 180 }).notNull(),
  size: varchar('size', { length: 40 }).notNull(),
  unitPrice: int('unitPrice').notNull(),
  quantity: int('quantity').notNull(),
});

export const adminAccounts = mysqlTable('adminAccounts', {
  id: int('id').autoincrement().primaryKey(),
  username: varchar('username', { length: 120 }).notNull().unique(),
  passwordHash: varchar('passwordHash', { length: 255 }).notNull(),
  displayName: varchar('displayName', { length: 160 }).notNull(),
  active: int('active').default(1).notNull(),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
});

export const adminSessions = mysqlTable('adminSessions', {
  id: int('id').autoincrement().primaryKey(),
  tokenHash: varchar('tokenHash', { length: 128 }).notNull().unique(),
  username: varchar('username', { length: 120 }).notNull(),
  expiresAt: timestamp('expiresAt').notNull(),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Customer = typeof customers.$inferSelect;
export type InventoryProduct = typeof inventoryProducts.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type AdminSession = typeof adminSessions.$inferSelect;
export type AdminAccount = typeof adminAccounts.$inferSelect;
