import { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, LockKeyhole, MessageCircle, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { isSupabasePhoneAuthConfigured, phoneAuthErrorMessage, requestPhoneOtp, verifyPhoneOtp } from '@/lib/phone-auth';

export default function PhoneVerification({ phone, onVerified }: { phone: string; onVerified: (normalizedPhone: string) => void }) {
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (!seconds) return; const timer = window.setInterval(() => setSeconds((current) => Math.max(0, current - 1)), 1000); return () => window.clearInterval(timer); }, [seconds]);

  const requestCode = async () => {
    if (!phone) return toast.error('ابتدا شماره موبایل را وارد کن.');
    if (!isSupabasePhoneAuthConfigured) return toast.error('اتصال Supabase هنوز تنظیم نشده است.');
    setLoading(true);
    try { await requestPhoneOtp(phone); setSent(true); setSeconds(60); toast.success('کد تأیید از طریق Supabase ارسال شد.'); }
    catch (error) { toast.error(phoneAuthErrorMessage(error)); }
    finally { setLoading(false); }
  };

  const verify = async () => {
    if (code.length !== 6) return;
    setLoading(true);
    try { await verifyPhoneOtp(phone, code); onVerified(phone); toast.success('شماره موبایل تأیید شد.'); }
    catch (error) { toast.error(phoneAuthErrorMessage(error)); }
    finally { setLoading(false); }
  };

  return <div className="mt-8 rounded-2xl border border-[var(--acid)]/25 bg-[var(--acid)]/[.06] p-4"><div className="flex items-start gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[var(--acid)] text-black"><LockKeyhole size={16}/></div><div className="min-w-0 flex-1"><p className="text-sm font-bold">تأیید شماره برای ثبت سفارش</p><p className="mt-1 text-xs leading-6 text-white/50">کد یک‌بارمصرف با Supabase Auth ارسال می‌شود؛ این لایه بعداً بدون تغییر رابط کاربری می‌تواند به provider دیگری متصل شود.</p>{!sent ? <button type="button" onClick={requestCode} disabled={loading || !phone} className="btn-primary mt-4 inline-flex items-center gap-2 text-xs">{loading ? <Loader2 className="animate-spin" size={14}/> : <MessageCircle size={14}/>} ارسال کد پیامکی</button> : <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center"><input inputMode="numeric" maxLength={6} value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))} placeholder="کد ۶ رقمی" className="w-full rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-center text-sm tracking-[.3em] outline-none focus:border-[var(--acid)] sm:w-36"/><button type="button" onClick={verify} disabled={loading || code.length !== 6} className="btn-primary inline-flex items-center justify-center gap-2 text-xs">{loading ? <Loader2 className="animate-spin" size={14}/> : <CheckCircle2 size={14}/>} تأیید</button><button type="button" disabled={seconds > 0 || loading} onClick={requestCode} className="text-xs text-white/45 hover:text-white disabled:cursor-not-allowed disabled:opacity-40"><RotateCcw size={13} className="inline"/> {seconds ? `${seconds} ثانیه تا ارسال مجدد` : 'ارسال مجدد'}</button></div>}</div></div></div>;
}
