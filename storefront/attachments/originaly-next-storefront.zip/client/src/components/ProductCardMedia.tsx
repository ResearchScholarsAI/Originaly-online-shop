import { Heart, Plus, ShoppingBag } from 'lucide-react';
import { Link } from 'wouter';
import type { Product } from '@/lib/catalog';

export default function ProductCardMedia({ product, href, wish, onToggle, onAdd }: { product: Product; href: string; wish: boolean; onToggle: () => void; onAdd: () => void }) {
  const hoverImage = product.gallery[1] && product.gallery[1] !== product.image ? product.gallery[1] : undefined;
  return <div className="group relative aspect-[.96] overflow-hidden bg-[#191d27]">
    <Link href={href}>
      <div className="absolute inset-0">
        <img src={product.image} alt={product.name} className={`h-full w-full object-cover transition duration-700 group-hover:scale-105 ${hoverImage ? 'group-hover:opacity-0' : ''}`} />
        {hoverImage && <img src={hoverImage} alt={`${product.name} نمای دوم`} className="absolute inset-0 h-full w-full object-cover opacity-0 transition duration-700 group-hover:scale-105 group-hover:opacity-100" />}
        <div className="absolute inset-0 bg-gradient-to-t from-[#101219] via-transparent to-transparent" />
      </div>
    </Link>
    <div className="pointer-events-none absolute right-4 top-4 flex gap-2"><span className="rounded-full border border-white/15 bg-black/30 px-2.5 py-1 text-[10px] font-bold backdrop-blur">{product.category}</span>{product.badge && <span className="rounded-full bg-[var(--acid)] px-2.5 py-1 text-[10px] font-black text-black">{product.badge}</span>}</div>
    <button type="button" aria-label="علاقه‌مندی" onClick={onToggle} className={`absolute left-4 top-4 grid h-9 w-9 place-items-center rounded-full border border-white/15 backdrop-blur transition ${wish ? 'bg-[var(--acid)] text-black' : 'bg-black/35 text-white'}`}><Heart size={15} fill={wish ? 'currentColor' : 'none'} /></button>
    <div className="absolute bottom-4 right-4 left-4 flex items-end justify-between gap-3"><Link href={href} className="min-w-0"><p className="text-[10px] uppercase tracking-[.16em] text-white/50">{product.brand}</p><h3 className="mt-1 truncate text-sm font-bold text-white">{product.name}</h3></Link><button type="button" aria-label="افزودن سریع به سبد" onClick={onAdd} className="quick-add grid h-10 shrink-0 place-items-center gap-1 rounded-full bg-white px-3 text-black transition hover:bg-[var(--acid)] sm:flex sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100"><ShoppingBag size={15} /><span className="hidden text-[10px] font-black sm:inline">افزودن سریع</span><Plus className="sm:hidden" size={14} /></button></div>
  </div>;
}
