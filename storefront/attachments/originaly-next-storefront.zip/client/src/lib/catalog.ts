export type Category = 'همه' | 'کفش' | 'پوشاک' | 'اکسسوری';
export type Product = {
  id: string;
  slug: string;
  name: string;
  brand: string;
  category: Exclude<Category, 'همه'>;
  gender: 'مردانه' | 'زنانه' | 'یونیسکس';
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  badge?: string;
  color: string;
  accent: string;
  image: string;
  gallery: string[];
  sizes: string[];
  description: string;
  details: string[];
  featured?: boolean;
  stock: number;
};

const shoeA = '/manus-storage/ub20-1_856d0145.jpg';
const shoeB = '/manus-storage/nb680-1_402df949.jpg';
const shoeC = '/manus-storage/asics-1_9e4f1c90.jpg';
const shoeD = '/manus-storage/boot-hiking_5600411b.jpg';
const coat = '/manus-storage/jacket_7d0c1c23.jpg';
const tee = '/manus-storage/hoodie_da166169.jpg';
const bag = '/manus-storage/reebok-1_f9045fda.jpg';
const cap = '/manus-storage/puma-1_4035dee6.jpg';
const ghost = '/manus-storage/ghost-1_bb6f75b7.jpg';
const court = '/manus-storage/court-1_71be32ed.jpg';
const reebok = '/manus-storage/reebok-1_f9045fda.jpg';
const brooks = '/manus-storage/brooks-2_5a1f0c8c.jpg';
const puma = '/manus-storage/puma-1_4035dee6.jpg';
const hoodie = '/manus-storage/hoodie_da166169.jpg';
const jacket = '/manus-storage/jacket_7d0c1c23.jpg';

export const products: Product[] = [
  {
    id: 'ub20-orange', slug: 'adidas-ultraboost-20-orange', name: 'Ultraboost 20 Solar Orange', brand: 'adidas', category: 'کفش', gender: 'یونیسکس', price: 6890000, compareAt: 7990000,
    rating: 4.9, reviews: 28, badge: 'انتخاب ویراستار', color: 'نارنجی خورشیدی', accent: '#ff7043', image: shoeA, gallery: [shoeA, shoeC, shoeD], sizes: ['40', '41', '42', '43', '44'],
    description: 'یک رانر نمادین با انرژی بازگشت بالا، رویهٔ تنفس‌پذیر و حس سبک برای حرکت شهری و تمرین روزانه.', details: ['رویهٔ Primeknit تنفس‌پذیر', 'کفی Boost برای بازگشت انرژی', 'ساختار پاشنهٔ تقویت‌شده', 'مناسب استفادهٔ روزانه و دویدن'], featured: true, stock: 8,
  },
  {
    id: 'new-balance-680', slug: 'new-balance-680-v8', name: 'Fresh Foam 680 v8', brand: 'new balance', category: 'کفش', gender: 'مردانه', price: 5740000, compareAt: 6290000,
    rating: 4.8, reviews: 19, badge: 'پرفروش', color: 'خاکستری مه‌آلود', accent: '#99a3b4', image: shoeB, gallery: [shoeB, shoeD], sizes: ['41', '42', '43', '44', '45'],
    description: 'تعادل دقیق بین نرمی و ثبات برای روزهایی که از صبح تا شب در حرکتید.', details: ['Fresh Foam نرم و پاسخ‌گو', 'زیرهٔ مقاوم در برابر سایش', 'وزن سبک شهری', 'بسته‌بندی اورجینال'], featured: true, stock: 12,
  },
  {
    id: 'nike-air-max-dn', slug: 'nike-air-max-dn-black', name: 'Air Max Dn Black Volt', brand: 'nike', category: 'کفش', gender: 'زنانه', price: 8290000,
    rating: 4.7, reviews: 14, badge: 'دراپ جدید', color: 'مشکی ولت', accent: '#c4ff2c', image: shoeC, gallery: [shoeC, shoeA], sizes: ['37', '38', '39', '40', '41'],
    description: 'سیلوئت آینده‌نگر و کفی پویا برای استایل خیابانی که قرار نیست شبیه بقیه باشد.', details: ['Air cushioning تمام‌قد', 'رویهٔ مشبک چندلایه', 'کفی داخلی قابل تعویض', 'اصالت‌سنجی پیش از ارسال'], featured: true, stock: 5,
  },
  {
    id: 'salomon-xt6', slug: 'salomon-xt6-ghost', name: 'XT-6 Ghost Grey', brand: 'salomon', category: 'کفش', gender: 'یونیسکس', price: 9180000,
    rating: 4.9, reviews: 11, badge: 'کالکشن محدود', color: 'گوست گری', accent: '#bfc5cc', image: shoeD, gallery: [shoeD, shoeB], sizes: ['40', '41', '42', '43', '44'],
    description: 'تکنیکال، مقاوم و آمادهٔ فرار از مسیرهای تکراری؛ برای استایل شهری با روحیهٔ ماجراجو.', details: ['سیستم Quicklace', 'زیرهٔ Contagrip', 'محافظ پنجهٔ مقاوم', 'تولید محدود فصل'], featured: true, stock: 3,
  },
  {
    id: 'north-face-nuptse', slug: 'the-north-face-nuptse-1996', name: '1996 Retro Nuptse', brand: 'the north face', category: 'پوشاک', gender: 'یونیسکس', price: 11900000, compareAt: 13400000,
    rating: 4.8, reviews: 22, badge: 'اورجینال', color: 'مشکی مات', accent: '#7d8ba1', image: coat, gallery: [coat, jacket], sizes: ['S', 'M', 'L', 'XL'],
    description: 'یک آیکون زمستانی با حجم درست، عایق سبک و فرم ماندگار که هر سال دوباره برمی‌گردد.', details: ['پرکنندهٔ عایق سبک', 'پوشش مقاوم در برابر رطوبت', 'جیب‌های زیپ‌دار', 'لیبل و بسته‌بندی اصلی'], stock: 7,
  },
  {
    id: 'nike-tech-tee', slug: 'nike-tech-tee-stone', name: 'Tech Essential Tee Stone', brand: 'nike', category: 'پوشاک', gender: 'مردانه', price: 1890000,
    rating: 4.6, reviews: 9, color: 'استون', accent: '#d4c6af', image: tee, gallery: [tee, hoodie], sizes: ['S', 'M', 'L', 'XL'],
    description: 'تی‌شرتی مینیمال برای ساختن استایل روزانه؛ پارچهٔ نرم با ایستایی تمیز.', details: ['پنبهٔ نرم شانه‌خورده', 'دوخت تقویت‌شده', 'فرم relaxed', 'شست‌وشوی آسان'], stock: 16,
  },
  {
    id: 'herschel-retreat', slug: 'herschel-retreat-backpack', name: 'Retreat Backpack Dark', brand: 'herschel', category: 'اکسسوری', gender: 'یونیسکس', price: 3270000,
    rating: 4.7, reviews: 16, badge: 'روزمره', color: 'دارک اولیو', accent: '#9aa878', image: bag, gallery: [bag, reebok], sizes: ['ONE SIZE'],
    description: 'یک همراه روزانهٔ خوش‌ساخت برای لپ‌تاپ، باشگاه و تمام مسیرهای بعدی.', details: ['محفظهٔ لپ‌تاپ ۱۵ اینچ', 'بندهای پددار', 'پارچهٔ مقاوم', 'ظرفیت ۱۹.۵ لیتر'], stock: 9,
  },
  {
    id: 'new-era-cap', slug: 'new-era-59fifty-cap', name: '59FIFTY NY Monochrome', brand: 'new era', category: 'اکسسوری', gender: 'یونیسکس', price: 2140000,
    rating: 4.8, reviews: 7, color: 'مشکی/سفید', accent: '#d8d7d2', image: cap, gallery: [cap, puma], sizes: ['7', '7 1/8', '7 1/4', '7 3/8'],
    description: 'کلاه فیت‌شدهٔ نمادین برای آخرین لایهٔ استایل؛ دقیق، تمیز و همیشه قابل اتکا.', details: ['فرم 59FIFTY', 'گلدوزی سه‌بعدی', 'لبهٔ صاف', 'سایزبندی دقیق'], stock: 6,
  },
  {
    id: 'nike-ghost-runner', slug: 'nike-ghost-runner-volt', name: 'Ghost Runner Volt', brand: 'nike', category: 'کفش', gender: 'یونیسکس', price: 4980000,
    rating: 4.6, reviews: 12, badge: 'تازه‌وارد', color: 'ولت / مشکی', accent: '#c4ff2c', image: ghost, gallery: [ghost, court], sizes: ['39', '40', '41', '42', '43'],
    description: 'فرمی سبک برای روزهایی که حرکت، بخشی از زبان شخصی توست.', details: ['رویهٔ مشبک تنفس‌پذیر', 'کفی سبک شهری', 'چسبندگی مناسب مسیرهای روزانه', 'بسته‌بندی آرشیوی محصول'], stock: 10,
  },
  {
    id: 'nike-court-vision', slug: 'nike-court-vision-low-white', name: 'Court Vision Low White', brand: 'nike', category: 'کفش', gender: 'زنانه', price: 4290000,
    rating: 4.5, reviews: 8, color: 'سفید خالص', accent: '#f3f3ef', image: court, gallery: [court, reebok], sizes: ['37', '38', '39', '40', '41'],
    description: 'مینیمال و بی‌زمان؛ برای استایلی که لازم نیست خودش را توضیح دهد.', details: ['رویهٔ ترکیبی مقاوم', 'زیرهٔ لاستیکی روزمره', 'فرم کم‌حجم', 'اصالت‌سنجی پیش از ارسال'], stock: 11,
  },
  {
    id: 'reebok-classic-leather', slug: 'reebok-classic-leather-chalk', name: 'Classic Leather Chalk', brand: 'reebok', category: 'کفش', gender: 'یونیسکس', price: 3790000,
    rating: 4.7, reviews: 13, badge: 'کلاسیک', color: 'کرم گچی', accent: '#e3d4b8', image: reebok, gallery: [reebok, puma], sizes: ['40', '41', '42', '43', '44'],
    description: 'کلاسیکی که با زمان قدیمی نمی‌شود؛ فقط شخصیت بیشتری پیدا می‌کند.', details: ['رویهٔ نرم و بادوام', 'کفی راحت شهری', 'دوخت تمیز کلاسیک', 'مناسب استفادهٔ روزانه'], stock: 8,
  },
  {
    id: 'asics-gel-kayano', slug: 'asics-gel-kayano-urban', name: 'Gel-Kayano Urban', brand: 'asics', category: 'کفش', gender: 'مردانه', price: 7650000,
    rating: 4.8, reviews: 10, badge: 'پرفروش', color: 'خاکستری شهری', accent: '#a8b4bf', image: brooks, gallery: [brooks, ghost], sizes: ['41', '42', '43', '44', '45'],
    description: 'پایداری و نرمی برای قدم‌هایی که قرار است بیشتر از امروز دوام بیاورند.', details: ['ساختار پشتیبان میانی', 'کفی نرم برای مسیر طولانی', 'رویهٔ چندلایه', 'بسته‌بندی اورجینال'], stock: 6,
  },
  {
    id: 'puma-palermo', slug: 'puma-palermo-classic', name: 'Palermo Classic', brand: 'puma', category: 'کفش', gender: 'یونیسکس', price: 4490000,
    rating: 4.6, reviews: 6, color: 'سرمه‌ای / سفید', accent: '#7280a9', image: puma, gallery: [puma, court], sizes: ['39', '40', '41', '42', '43'],
    description: 'یک امضای شهری برای کسانی که جزئیات را آرام اما دقیق انتخاب می‌کنند.', details: ['فرم low-profile', 'رویهٔ مقاوم', 'زیرهٔ چسبنده', 'مناسب استایل روزمره'], stock: 9,
  },
  {
    id: 'originaly-heavy-hoodie', slug: 'originaly-heavy-hoodie-graphite', name: 'Heavyweight Hoodie Graphite', brand: 'originaly', category: 'پوشاک', gender: 'یونیسکس', price: 2850000,
    rating: 4.8, reviews: 15, badge: 'ویراست Originaly', color: 'گرافیت', accent: '#7e8795', image: hoodie, gallery: [hoodie, jacket], sizes: ['S', 'M', 'L', 'XL'],
    description: 'لایه‌ای آرام برای روزهایی که کیفیت، بلندتر از لوگو حرف می‌زند.', details: ['پنبهٔ سنگین و نرم', 'فرم آزاد معاصر', 'کلاه دوبل', 'دوخت تقویت‌شده'], stock: 14,
  },
  {
    id: 'the-north-face-shell', slug: 'the-north-face-shell-olive', name: 'Urban Shell Olive', brand: 'the north face', category: 'پوشاک', gender: 'مردانه', price: 8490000,
    rating: 4.7, reviews: 9, badge: 'لایهٔ بیرونی', color: 'زیتونی', accent: '#9aa878', image: jacket, gallery: [jacket, hoodie], sizes: ['S', 'M', 'L', 'XL'],
    description: 'محافظی سبک برای هوایی که همیشه طبق برنامه پیش نمی‌رود.', details: ['پارچهٔ مقاوم در برابر باد', 'جیب‌های کاربردی', 'فرم قابل لایه‌پوشی', 'زیپ‌های روان'], stock: 5,
  },
  {
    id: 'originaly-trail-boot', slug: 'originaly-trail-boot-sand', name: 'Trail Boot Sand', brand: 'originaly edit', category: 'اکسسوری', gender: 'یونیسکس', price: 5290000,
    rating: 4.5, reviews: 5, color: 'شن‌زار', accent: '#c6a77b', image: shoeD, gallery: [shoeD, shoeA], sizes: ['40', '41', '42', '43', '44'],
    description: 'برای مسیرهایی که هنوز روی نقشهٔ روزمره‌ات علامت نخورده‌اند.', details: ['زیرهٔ مقاوم مسیر', 'محافظ پنجه', 'بندهای محکم', 'مناسب سفر و طبیعت'], stock: 4,
  },
];

export const categories: { label: Category; hint: string; icon: string }[] = [
  { label: 'همه', hint: 'ویراست کامل', icon: '✦' },
  { label: 'کفش', hint: 'حرکت بعدی', icon: '◒' },
  { label: 'پوشاک', hint: 'لایهٔ اصلی', icon: '◐' },
  { label: 'اکسسوری', hint: 'امضای نهایی', icon: '◈' },
];

export function getProduct(slug: string) { return products.find((product) => product.slug === slug); }
export function formatPrice(value: number) { return `${new Intl.NumberFormat('fa-IR').format(value)} تومان`; }
export function discountPercent(product: Product) { return product.compareAt ? Math.round((1 - product.price / product.compareAt) * 100) : 0; }

export const editorialCards = [
  { eyebrow: '01 / CITY RUNNER', title: 'برای خیابان‌هایی که هنوز کشف نشده‌اند.', copy: 'کفش‌هایی که فقط دیده نمی‌شوند؛ مسیر حرکتت را تعریف می‌کنند.', image: shoeA, tone: 'from-[#ff7043]/70 via-[#151923]/30 to-[#090a0f]' },
  { eyebrow: '02 / COLD FORM', title: 'لایه‌های گرم، فرم‌های سرد.', copy: 'پوشاکی برای هوای سرد و ذهنی که گرم می‌ماند.', image: coat, tone: 'from-[#9aa878]/70 via-[#11151b]/30 to-[#090a0f]' },
];

export const promises = [
  { number: '01', title: 'اصالت‌سنجی دو مرحله‌ای', copy: 'هر آیتم قبل از خروج از استودیو توسط تیم Originaly بررسی می‌شود.' },
  { number: '02', title: 'سازندگی و برازندگی', copy: 'هر انتخاب خوب، بخشی از ساختن سبک زندگی توست؛ ما فقط آن را دقیق‌تر می‌کنیم.' },
  { number: '03', title: 'مسیرهای دیده‌نشده', copy: 'کفش‌هایی برای قدم‌هایی که قرار نیست روی ردپای دیگران راه بروند.' },
];
