import { createClient, type SupabaseClient } from '@supabase/supabase-js';

export type PhoneOtpProvider = 'supabase' | 'custom';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabasePhoneAuthConfigured = Boolean(supabaseUrl && supabaseAnonKey);
export const phoneAuthProvider: PhoneOtpProvider = 'supabase';

export const supabase: SupabaseClient | null = isSupabasePhoneAuthConfigured
  ? createClient(supabaseUrl!, supabaseAnonKey!, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
  : null;

export function normalizePhoneForSupabase(value: string) {
  const digits = value.trim().replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))).replace(/[\s()-]/g, '').replace(/^00/, '+');
  if (digits.startsWith('09')) return `+98${digits.slice(1)}`;
  if (digits.startsWith('98')) return `+${digits}`;
  return digits;
}

export function phoneAuthErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : String(error ?? '');
  const normalized = message.toLowerCase();
  if (normalized.includes('unsupported phone provider') || normalized.includes('phone provider')) return 'ارسال پیامک در پروژهٔ Supabase فعال نشده است. در Supabase از مسیر Authentication → Providers → Phone، یک SMS provider را فعال و تنظیم کنید.';
  if (normalized.includes('rate limit') || normalized.includes('too many')) return 'تعداد درخواست‌ها بیش از حد مجاز است؛ چند دقیقه بعد دوباره تلاش کنید.';
  if (normalized.includes('invalid phone') || normalized.includes('phone number')) return 'شماره را به‌صورت ۰۹۱۲۱۲۳۴۵۶۷ یا +989121234567 وارد کنید.';
  if (normalized === 'supabase_not_configured') return 'اتصال Supabase هنوز در محیط اجرا تنظیم نشده است.';
  return 'ارسال کد انجام نشد؛ تنظیمات Phone provider و شمارهٔ واردشده را بررسی کنید.';
}

export async function requestPhoneOtp(phone: string) {
  if (!supabase) throw new Error('supabase_not_configured');
  const { error } = await supabase.auth.signInWithOtp({ phone: normalizePhoneForSupabase(phone), options: { shouldCreateUser: true } });
  if (error) throw new Error(phoneAuthErrorMessage(error));
}

export async function verifyPhoneOtp(phone: string, token: string) {
  if (!supabase) throw new Error('supabase_not_configured');
  const { data, error } = await supabase.auth.verifyOtp({ phone: normalizePhoneForSupabase(phone), token, type: 'sms' });
  if (error) throw new Error(phoneAuthErrorMessage(error));
  return data;
}

export async function getSupabaseAccessToken() {
  if (!supabase) throw new Error('supabase_not_configured');
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error('supabase_session_missing');
  return data.session.access_token;
}

export async function signOutPhoneAuth() {
  if (!supabase) return;
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}
