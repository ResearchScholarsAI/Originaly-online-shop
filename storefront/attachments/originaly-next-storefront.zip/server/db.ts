import { and, desc, eq, gte, gt, isNull, sql } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/mysql2';
import { createHash, pbkdf2Sync, randomBytes } from 'node:crypto';
import { ENV } from './_core/env';
import { adminAccounts, adminSessions, customers, inventoryProducts, orderItems, orders, otpChallenges, users, type InsertUser } from '../drizzle/schema';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn('[Database] Failed to connect:', error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error('User openId is required for upsert');
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ['name', 'email', 'loginMethod'] as const;
  for (const field of textFields) { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } }
  values.lastSignedIn = user.lastSignedIn ?? new Date(); updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0];
}

const digitMap: Record<string, string> = { '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9','٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9' };
export function normalizePhone(input: string) {
  let phone = input.trim().replace(/[۰-۹٠-٩]/g, (digit) => digitMap[digit] || digit).replace(/[\s()-]/g, '');
  if (phone.startsWith('+98')) phone = `0${phone.slice(3)}`;
  if (phone.startsWith('0098')) phone = `0${phone.slice(4)}`;
  if (/^98\d{10}$/.test(phone)) phone = `0${phone.slice(2)}`;
  return phone;
}

function digest(value: string, salt: string) { return pbkdf2Sync(value, salt, 120000, 32, 'sha256').toString('hex'); }
export function hashSecret(value: string) { const salt = randomBytes(16).toString('hex'); return `pbkdf2$120000$${salt}$${digest(value, salt)}`; }
export function verifySecret(value: string, encoded: string) { const [, rounds, salt, expected] = encoded.split('$'); if (!rounds || !salt || !expected) return false; const actual = pbkdf2Sync(value, salt, Number(rounds), 32, 'sha256').toString('hex'); return actual.length === expected.length && actual === expected; }
function hashToken(value: string) { return createHash('sha256').update(value).digest('hex'); }

export async function createOtp(phoneInput: string) {
  const db = await getDb(); if (!db) throw new Error('database_unavailable');
  const phone = normalizePhone(phoneInput);
  if (!/^09\d{9}$/.test(phone)) throw new Error('invalid_phone');
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  await db.insert(otpChallenges).values({ phone, codeHash: hashSecret(code), expiresAt: new Date(Date.now() + 5 * 60 * 1000) });
  const delivered = await sendOtpSms(phone, code);
  return { phone, delivered, expiresIn: 300, developmentCode: delivered || ENV.isProduction ? undefined : code };
}

async function sendOtpSms(phone: string, code: string) {
  if (!ENV.kavenegarApiKey || !ENV.kavenegarTemplate) { console.warn('[SMS] Kavenegar secrets are not configured; OTP is not sent.'); return false; }
  const endpoint = `https://api.kavenegar.com/v1/${encodeURIComponent(ENV.kavenegarApiKey)}/verify/lookup.json`;
  const body = new URLSearchParams({ receptor: phone, token: code, template: ENV.kavenegarTemplate });
  const response = await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
  if (!response.ok) throw new Error('sms_provider_error');
  const payload = await response.json() as { return?: { status?: number } };
  if (payload.return?.status !== 200) throw new Error('sms_provider_rejected');
  return true;
}

export async function verifyOtp(phoneInput: string, code: string) {
  const db = await getDb(); if (!db) throw new Error('database_unavailable');
  const phone = normalizePhone(phoneInput);
  const rows = await db.select().from(otpChallenges).where(and(eq(otpChallenges.phone, phone), isNull(otpChallenges.consumedAt), gt(otpChallenges.expiresAt, new Date()))).orderBy(desc(otpChallenges.createdAt)).limit(1);
  const challenge = rows[0];
  if (!challenge || challenge.attempts >= 5 || !verifySecret(code, challenge.codeHash)) {
    if (challenge) await db.update(otpChallenges).set({ attempts: challenge.attempts + 1 }).where(eq(otpChallenges.id, challenge.id));
    return false;
  }
  await db.update(otpChallenges).set({ consumedAt: new Date() }).where(eq(otpChallenges.id, challenge.id));
  await db.insert(customers).values({ phone, phoneVerifiedAt: new Date() }).onDuplicateKeyUpdate({ set: { phoneVerifiedAt: new Date(), updatedAt: new Date() } });
  return true;
}

export async function upsertSupabaseCustomer(input: { supabaseUserId: string; phone: string; email?: string; fullName?: string; city?: string; address?: string; postalCode?: string; phoneConfirmed: boolean; marketingConsent: boolean }) {
  const db = await getDb(); if (!db) throw new Error('database_unavailable');
  const phone = normalizePhone(input.phone);
  if (!/^09\d{9}$/.test(phone)) throw new Error('invalid_phone');
  const now = new Date();
  await db.insert(customers).values({ phone, supabaseUserId: input.supabaseUserId, authProvider: 'supabase', authStatus: input.phoneConfirmed ? 'verified' : 'unverified', lastAuthAt: now, phoneVerifiedAt: input.phoneConfirmed ? now : undefined, email: input.email, fullName: input.fullName, city: input.city, address: input.address, postalCode: input.postalCode, marketingConsentAt: input.marketingConsent ? now : undefined }).onDuplicateKeyUpdate({ set: { supabaseUserId: input.supabaseUserId, authProvider: 'supabase', authStatus: input.phoneConfirmed ? 'verified' : 'unverified', lastAuthAt: now, phoneVerifiedAt: input.phoneConfirmed ? now : undefined, email: input.email, fullName: input.fullName, city: input.city, address: input.address, postalCode: input.postalCode, marketingConsentAt: input.marketingConsent ? now : undefined, updatedAt: now } });
  const rows = await db.select().from(customers).where(eq(customers.supabaseUserId, input.supabaseUserId)).limit(1); return rows[0];
}
export async function getCustomerBySupabaseUserId(supabaseUserId: string) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(customers).where(eq(customers.supabaseUserId, supabaseUserId)).limit(1); return rows[0]; }

export async function getAdminAccounts() { const db = await getDb(); return db ? db.select({ id: adminAccounts.id, username: adminAccounts.username, displayName: adminAccounts.displayName, active: adminAccounts.active, createdAt: adminAccounts.createdAt }).from(adminAccounts).orderBy(desc(adminAccounts.createdAt)) : []; }

export async function getCustomers() { const db = await getDb(); return db ? db.select().from(customers).orderBy(desc(customers.createdAt)) : []; }
export async function getOrders() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  return Promise.all(rows.map(async (order) => {
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
    return { ...order, productsSummary: items.map((item) => `${item.productName} × ${item.quantity} (${item.size})`).join('، ') || '—', items };
  }));
}
export async function getInventory() { const db = await getDb(); return db ? db.select().from(inventoryProducts).orderBy(desc(inventoryProducts.updatedAt)) : []; }
export async function updateInventory(id: number, stock: number, price: number, active: number) { const db = await getDb(); if (!db) throw new Error('database_unavailable'); await db.update(inventoryProducts).set({ stock, price, active, updatedAt: new Date() }).where(eq(inventoryProducts.id, id)); return true; }
export async function createInventoryProduct(input: { sku: string; slug: string; name: string; brand: string; category: string; price: number; stock: number; imageUrl?: string }) { const db = await getDb(); if (!db) throw new Error('database_unavailable'); await db.insert(inventoryProducts).values({ ...input, active: 1 }); return true; }

export async function createAdminSession(username: string) {
  const db = await getDb(); if (!db) throw new Error('database_unavailable');
  const rawToken = randomBytes(32).toString('base64url');
  await db.insert(adminSessions).values({ username, tokenHash: hashToken(rawToken), expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000) });
  return rawToken;
}
export async function getAdminAccount(username: string) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(adminAccounts).where(and(eq(adminAccounts.username, username), eq(adminAccounts.active, 1))).limit(1); return rows[0]; }
export async function getAdminSession(rawToken: string | undefined) { const db = await getDb(); if (!db || !rawToken) return undefined; const rows = await db.select().from(adminSessions).where(and(eq(adminSessions.tokenHash, hashToken(rawToken)), gt(adminSessions.expiresAt, new Date()))).limit(1); return rows[0]; }
export async function deleteAdminSession(rawToken: string | undefined) { const db = await getDb(); if (db && rawToken) await db.delete(adminSessions).where(eq(adminSessions.tokenHash, hashToken(rawToken))); }

export async function createOrder(input: { trackingCode: string; customerId?: number; customerPhone: string; customerName: string; city: string; address: string; postalCode: string; subtotal: number; shipping: number; total: number; items: { sku: string; productName: string; size: string; unitPrice: number; quantity: number }[] }) {
  const db = await getDb(); if (!db) throw new Error('database_unavailable');
  await db.transaction(async (tx) => {
    let subtotal = 0;
    for (const item of input.items) {
      const product = (await tx.select().from(inventoryProducts).where(and(eq(inventoryProducts.sku, item.sku), eq(inventoryProducts.active, 1))).limit(1))[0];
      if (!product || product.stock < item.quantity) throw new Error(`out_of_stock:${item.productName}`);
      subtotal += product.price * item.quantity;
    }
    const shipping = subtotal >= 8000000 || subtotal === 0 ? 0 : 120000;
    const total = subtotal + shipping;
    for (const item of input.items) {
      await tx.update(inventoryProducts).set({ stock: sql`${inventoryProducts.stock} - ${item.quantity}`, updatedAt: new Date() }).where(and(eq(inventoryProducts.sku, item.sku), eq(inventoryProducts.active, 1), gte(inventoryProducts.stock, item.quantity)));
    }
    await tx.insert(orders).values({ trackingCode: input.trackingCode, customerId: input.customerId, customerPhone: normalizePhone(input.customerPhone), customerName: input.customerName, city: input.city, address: input.address, postalCode: input.postalCode, subtotal, shipping, total });
    const created = await tx.select({ id: orders.id }).from(orders).where(eq(orders.trackingCode, input.trackingCode)).limit(1);
    if (created[0]) await tx.insert(orderItems).values(input.items.map((item) => ({ orderId: created[0].id, ...item })));
  });
  return input.trackingCode;
}
