import { describe, expect, it } from 'vitest';
import { normalizePhoneForSupabase, phoneAuthErrorMessage } from '../client/src/lib/phone-auth';

describe('provider-swappable phone auth', () => {
  it('normalizes Iranian mobile numbers to E.164', () => {
    expect(normalizePhoneForSupabase('09121234567')).toBe('+989121234567');
    expect(normalizePhoneForSupabase('+989121234567')).toBe('+989121234567');
  });

  it('preserves international numbers', () => {
    expect(normalizePhoneForSupabase('+447911123456')).toBe('+447911123456');
  });

  it('normalizes Persian digits entered in the checkout form', () => {
    expect(normalizePhoneForSupabase('۰۹۱۲۱۲۳۴۵۶۷')).toBe('+989121234567');
  });

  it('explains when Supabase has no SMS provider configured', () => {
    expect(phoneAuthErrorMessage(new Error('Unsupported phone provider'))).toContain('SMS provider');
  });
});
