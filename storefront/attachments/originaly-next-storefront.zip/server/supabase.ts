import { ENV } from './_core/env';

export type SupabaseAuthUser = {
  id: string;
  phone?: string;
  email?: string;
  phone_confirmed_at?: string | null;
  user_metadata?: Record<string, unknown>;
};

export async function getSupabaseAuthUser(accessToken: string): Promise<SupabaseAuthUser> {
  if (!ENV.supabaseUrl || !ENV.supabaseAnonKey) throw new Error('supabase_not_configured');
  const response = await fetch(`${ENV.supabaseUrl}/auth/v1/user`, { headers: { apikey: ENV.supabaseAnonKey, authorization: `Bearer ${accessToken}` } });
  if (!response.ok) throw new Error('supabase_session_invalid');
  return response.json() as Promise<SupabaseAuthUser>;
}
