import { describe, expect, it } from 'vitest';

describe('Supabase project configuration', () => {
  it('accepts the configured project URL and published key', async () => {
    const url = process.env.VITE_SUPABASE_URL;
    const key = process.env.VITE_SUPABASE_ANON_KEY;
    expect(url, 'VITE_SUPABASE_URL is required').toMatch(/^https:\/\/[^\s/]+\.supabase\.co\/?$/);
    expect(key, 'VITE_SUPABASE_ANON_KEY is required').toMatch(/^sb_publishable_[A-Za-z0-9_-]+$/);
    const response = await fetch(`${url!.replace(/\/$/, '')}/auth/v1/settings`, { headers: { apikey: key! } });
    expect(response.ok, `Supabase settings endpoint returned ${response.status}`).toBe(true);
  }, 15000);
});
