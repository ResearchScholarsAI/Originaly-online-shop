import { TRPCError } from '@trpc/server';
import { parse } from 'cookie';
import { z } from 'zod';
import { COOKIE_NAME } from '@shared/const';
import { getSessionCookieOptions } from './_core/cookies';
import { systemRouter } from './_core/systemRouter';
import { publicProcedure, router } from './_core/trpc';
import { getSupabaseAuthUser } from './supabase';
import { createAdminSession, createInventoryProduct, createOrder, createOtp, deleteAdminSession, getAdminAccount, getAdminAccounts, getAdminSession, getCustomerBySupabaseUserId, getCustomers, getInventory, getOrders, hashSecret, normalizePhone, updateInventory, upsertSupabaseCustomer, verifyOtp, verifySecret } from './db';

const adminCookie = 'originaly_admin_session';
function readCookie(req: { headers: { cookie?: string } }) { return parse(req.headers.cookie || '')[adminCookie]; }
async function requireAdmin(ctx: { req: { headers: { cookie?: string } } }) {
  const session = await getAdminSession(readCookie(ctx.req));
  if (!session) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'نشست مدیریت معتبر نیست.' });
  return session;
}
function setAdminCookie(ctx: { req: any; res: any }, token: string) { ctx.res.cookie(adminCookie, token, { ...getSessionCookieOptions(ctx.req), maxAge: 8 * 60 * 60 * 1000 }); }
function clearAdminCookie(ctx: { req: any; res: any }) { ctx.res.clearCookie(adminCookie, { ...getSessionCookieOptions(ctx.req), maxAge: -1 }); }

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  customer: router({
    sendOtp: publicProcedure.input(z.object({ phone: z.string().min(8).max(20) })).mutation(async ({ input }) => {
      try { return await createOtp(input.phone); } catch (error) { const message = error instanceof Error ? error.message : 'otp_failed'; if (message === 'invalid_phone') throw new TRPCError({ code: 'BAD_REQUEST', message: 'شماره موبایل معتبر نیست.' }); throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'ارسال کد با مشکل مواجه شد.' }); }
    }),
    verifyOtp: publicProcedure.input(z.object({ phone: z.string(), code: z.string().regex(/^\d{6}$/) })).mutation(async ({ input }) => { const verified = await verifyOtp(input.phone, input.code); if (!verified) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'کد واردشده صحیح یا معتبر نیست.' }); return { verified: true, phone: normalizePhone(input.phone) }; }),
    profile: publicProcedure.input(z.object({ accessToken: z.string().min(20) })).mutation(async ({ input }) => { const authUser = await getSupabaseAuthUser(input.accessToken); if (!authUser.id) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'نشست Supabase معتبر نیست.' }); return getCustomerBySupabaseUserId(authUser.id); }),
    syncProfile: publicProcedure.input(z.object({ accessToken: z.string().min(20), fullName: z.string().min(2).max(160).optional(), city: z.string().max(100).optional(), address: z.string().max(2000).optional(), postalCode: z.string().max(20).optional(), marketingConsent: z.boolean().default(false) })).mutation(async ({ input }) => {
      try {
        const authUser = await getSupabaseAuthUser(input.accessToken);
        if (!authUser.id || !authUser.phone) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'حساب Supabase شماره موبایل معتبری ندارد.' });
        const profile = await upsertSupabaseCustomer({ supabaseUserId: authUser.id, phone: authUser.phone, email: authUser.email, fullName: input.fullName, city: input.city, address: input.address, postalCode: input.postalCode, phoneConfirmed: Boolean(authUser.phone_confirmed_at), marketingConsent: input.marketingConsent });
        return { profile, phone: normalizePhone(authUser.phone), supabaseUserId: authUser.id, authStatus: profile?.authStatus ?? 'unverified' };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        const message = error instanceof Error ? error.message : 'sync_failed';
        if (message === 'supabase_not_configured') throw new TRPCError({ code: 'PRECONDITION_FAILED', message: 'Supabase هنوز در Secrets پروژه تنظیم نشده است.' });
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'نشست Supabase معتبر نیست یا منقضی شده است.' });
      }
    }),
  }),
  admin: router({
    login: publicProcedure.input(z.object({ username: z.string().min(3).max(120), password: z.string().min(8).max(200) })).mutation(async ({ ctx, input }) => { const account = await getAdminAccount(input.username.trim()); if (!account || !verifySecret(input.password, account.passwordHash)) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'نام کاربری یا رمز عبور صحیح نیست.' }); const token = await createAdminSession(account.username); setAdminCookie(ctx, token); return { username: account.username, displayName: account.displayName }; }),
    me: publicProcedure.query(async ({ ctx }) => { const session = await getAdminSession(readCookie(ctx.req)); return session ? { username: session.username } : null; }),
    accounts: publicProcedure.query(async ({ ctx }) => { await requireAdmin(ctx); return getAdminAccounts(); }),
    logout: publicProcedure.mutation(async ({ ctx }) => { await deleteAdminSession(readCookie(ctx.req)); clearAdminCookie(ctx); return { success: true }; }),
    customers: publicProcedure.query(async ({ ctx }) => { await requireAdmin(ctx); return getCustomers(); }),
    orders: publicProcedure.query(async ({ ctx }) => { await requireAdmin(ctx); return getOrders(); }),
    inventory: publicProcedure.query(async ({ ctx }) => { await requireAdmin(ctx); return getInventory(); }),
    updateInventory: publicProcedure.input(z.object({ id: z.number().int().positive(), stock: z.number().int().min(0), price: z.number().int().min(0), active: z.number().int().min(0).max(1) })).mutation(async ({ ctx, input }) => { await requireAdmin(ctx); await updateInventory(input.id, input.stock, input.price, input.active); return { success: true }; }),
    createInventoryProduct: publicProcedure.input(z.object({ sku: z.string().min(2).max(80), slug: z.string().min(2).max(180), name: z.string().min(2).max(180), brand: z.string().min(2).max(120), category: z.string().min(2).max(80), price: z.number().int().min(0), stock: z.number().int().min(0), imageUrl: z.string().url().optional() })).mutation(async ({ ctx, input }) => { await requireAdmin(ctx); await createInventoryProduct(input); return { success: true }; }),
    addAdmin: publicProcedure.input(z.object({ username: z.string().min(3).max(120), password: z.string().min(12).max(200), displayName: z.string().min(2).max(160) })).mutation(async ({ ctx, input }) => { await requireAdmin(ctx); const db = await (await import('./db')).getDb(); if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' }); const { adminAccounts } = await import('../drizzle/schema'); await db.insert(adminAccounts).values({ username: input.username, passwordHash: hashSecret(input.password), displayName: input.displayName, active: 1 }); return { success: true }; }),
    exportCsv: publicProcedure.input(z.object({ entity: z.enum(['customers', 'orders', 'inventory']) })).mutation(async ({ ctx, input }) => { await requireAdmin(ctx); const rows = input.entity === 'customers' ? await getCustomers() : input.entity === 'orders' ? await getOrders() : await getInventory(); if (!rows.length) return ''; const headers = Object.keys(rows[0] as object); const csv = [headers.join(','), ...rows.map((row) => headers.map((key) => JSON.stringify((row as Record<string, unknown>)[key] ?? '')).join(','))].join('\n'); return `\uFEFF${csv}`; }),
  }),
  checkout: router({
    createOrder: publicProcedure.input(z.object({ accessToken: z.string().min(20), trackingCode: z.string().min(5), customerPhone: z.string(), customerName: z.string().min(2), city: z.string().min(2), address: z.string().min(8), postalCode: z.string().min(5), subtotal: z.number().int().min(0), shipping: z.number().int().min(0), total: z.number().int().min(0), items: z.array(z.object({ sku: z.string(), productName: z.string(), size: z.string(), unitPrice: z.number().int().min(0), quantity: z.number().int().positive() })).min(1) })).mutation(async ({ input }) => { const authUser = await getSupabaseAuthUser(input.accessToken); if (!authUser.phone || !authUser.phone_confirmed_at || normalizePhone(authUser.phone) !== normalizePhone(input.customerPhone)) throw new TRPCError({ code: 'UNAUTHORIZED', message: 'ثبت سفارش فقط با شمارهٔ تأییدشدهٔ Supabase مجاز است.' }); const customer = await getCustomerBySupabaseUserId(authUser.id); const { accessToken: _accessToken, ...orderInput } = input; try { return { trackingCode: await createOrder({ ...orderInput, customerId: customer?.id }) }; } catch (error) { const message = error instanceof Error ? error.message : ''; if (message.startsWith('out_of_stock:')) throw new TRPCError({ code: 'CONFLICT', message: `موجودی محصول کافی نیست: ${message.slice('out_of_stock:'.length)}` }); throw error; } }),
  }),
});

export type AppRouter = typeof appRouter;
