export const ENV = {
  appId: process.env.VITE_APP_ID ?? '',
  cookieSecret: process.env.JWT_SECRET ?? '',
  databaseUrl: process.env.DATABASE_URL ?? '',
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? '',
  ownerOpenId: process.env.OWNER_OPEN_ID ?? '',
  isProduction: process.env.NODE_ENV === 'production',
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? '',
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? '',
  kavenegarApiKey: process.env.KAVENEGAR_API_KEY ?? '',
  kavenegarTemplate: process.env.KAVENEGAR_OTP_TEMPLATE ?? '',
  supabaseUrl: process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL ?? '',
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY ?? process.env.VITE_SUPABASE_ANON_KEY ?? '',
};
