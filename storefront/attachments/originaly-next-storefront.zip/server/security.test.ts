import { describe, expect, it } from 'vitest';
import { hashSecret, normalizePhone, verifySecret } from './db';

describe('Originaly security helpers', () => {
  it('normalizes common Iranian phone formats', () => {
    expect(normalizePhone('+989121234567')).toBe('09121234567');
    expect(normalizePhone('۰۰۹۸۹۱۲۱۲۳۴۵۶۷')).toBe('09121234567');
  });

  it('uses salted one-way hashes for credentials', () => {
    const encoded = hashSecret('A-strong-secret-123');
    expect(encoded.startsWith('pbkdf2$')).toBe(true);
    expect(verifySecret('A-strong-secret-123', encoded)).toBe(true);
    expect(verifySecret('wrong-secret', encoded)).toBe(false);
  });
});
