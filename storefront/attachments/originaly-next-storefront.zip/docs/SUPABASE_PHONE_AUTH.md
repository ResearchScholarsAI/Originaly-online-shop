# احراز هویت تلفنی Originaly با Supabase

## وضعیت فعلی

رابط تأیید شمارهٔ موبایل در checkout از **Supabase Auth Phone OTP** استفاده می‌کند. رابط کاربری به provider خاصی وابسته نیست و تمام ارتباط از طریق `client/src/lib/phone-auth.ts` انجام می‌شود. برای تغییر سرویس در آینده، همین فایل می‌تواند با adapter سرویس جدید جایگزین شود و کامپوننت checkout و مسیر خرید تغییر نکند.

## تنظیمات لازم در Supabase

در Supabase از مسیر **Authentication → Providers → Phone**، Phone provider را فعال کنید و SMS provider موردنظر را تنظیم کنید. برای محیط آزمایشی می‌توان از test phone numbers خود Supabase استفاده کرد؛ برای production باید یک سرویس پیامکی فعال و الگوی مجاز آن provider را تنظیم کنید.

مقادیر عمومی پروژه را در Secrets پروژهٔ وب قرار دهید:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
```

کلید `service_role` نباید در مرورگر، فایل ZIP یا مخزن GitHub قرار گیرد.

## قرارداد قابل تعویض

توابع عمومی adapter عبارت‌اند از:

- `requestPhoneOtp(phone)` برای ارسال کد.
- `verifyPhoneOtp(phone, token)` برای تأیید کد.
- `normalizePhoneForSupabase(phone)` برای تبدیل شمارهٔ ایران به قالب E.164.

برای مهاجرت آتی به Kavenegar، Twilio یا provider دیگر، فقط implementation این توابع تغییر می‌کند؛ checkout و پنل فروشگاه همان API را مصرف خواهند کرد.

## حالت بدون credentials

تا زمانی که `VITE_SUPABASE_URL` و `VITE_SUPABASE_ANON_KEY` تنظیم نشده باشند، دکمهٔ OTP به‌درستی پیام می‌دهد که اتصال تنظیم نشده است و هیچ کد جعلی یا موفقیت ساختگی نمایش داده نمی‌شود. این رفتار عمداً برای جلوگیری از ثبت سفارش غیرقابل‌اعتماد در production انتخاب شده است.

## همگام‌سازی پروفایل با دیتابیس فروشگاه

پس از موفقیت OTP، Supabase access token فقط از مسیر HTTPS به procedureهای tRPC ارسال می‌شود. سرور با endpoint `auth/v1/user` سوپابیس توکن را اعتبارسنجی می‌کند و سپس رکورد `customers` را بر اساس `supabaseUserId` و شمارهٔ نرمال‌شدهٔ کاربر upsert می‌کند. ستون‌های `authProvider`، `authStatus`، `phoneVerifiedAt` و `lastAuthAt` وضعیت احراز را ثبت می‌کنند.

صفحهٔ `/account` برای مشاهده و ویرایش نام، شهر، آدرس، کدپستی و رضایت بازاریابی اضافه شده است. پیش از ثبت سفارش نیز پروفایل دوباره sync می‌شود و procedure ثبت سفارش، توکن Supabase و تأیید تلفن را در سمت سرور بررسی می‌کند؛ بنابراین ارسال مستقیم payload جعلی از مرورگر نمی‌تواند شمارهٔ تأییدنشده را به‌عنوان مشتری معتبر ثبت کند.
